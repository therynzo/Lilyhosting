<div class="row">
  <div class="col-xs-12">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Lily Theme <small>v1.0.0</small></h3>
      </div>
      <div class="box-body">
        <p>The Lily Hosting purple glass theme is active on the client area and this admin area.</p>
        <p>To remove it, run <code>blueprint -r lilytheme</code> in your panel folder.</p>
      </div>
    </div>
  </div>
</div>
